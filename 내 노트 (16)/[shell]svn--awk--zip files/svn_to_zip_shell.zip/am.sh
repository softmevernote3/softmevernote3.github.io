#!/bin/sh
argv0=$1
cd /cygdrive/e/workspace/upay_work/lgu_upay_admin/trunk
# svn diff -r 22:HEAD --summarize
# exit
#echo $#
#echo $PATH
if [ 1 -eq $# ]
    file_name=$(date +%Y%m%d%H%M%S)
    svn diff -r $argv0:HEAD --summarize | awk '{print $NF}' | zip -@ $file_name.zip
    echo 
    echo 
    echo 
    echo /cygdrive/e/workspace/upay_work/lgu_upay_admin/trunk/$file_name.zip
    /bin/cygstart /cygdrive/e/workspace/upay_work/lgu_upay_admin/trunk
    # /bin/cygstart /cygdrive/e/workspace/upay_work/lgu_upay_admin/trunk/$file_name.zip
    exit
then
    echo - Using -------------------------------------------
    echo am.sh [revision]
    echo ----------------------------------------------------
    exit
fi
